# ANDROMAX

Painel desktop (Windows, Linux, macOS) para gerir instâncias Android virtuais.

> **Estado honesto:** a interface, o gestor de instâncias, a deteção de capacidades e a integração ADB estão implementados e testados com testes unitários. O arranque real do Android (QEMU + imagem Android) é **experimental e ainda não foi validado em hardware real**. Ver `STATUS.md` e `LIMITATIONS.md`.

## O que funciona

- Interface em português, tema escuro/claro, navegação por teclado.
- Criar, configurar, clonar, exportar/importar e eliminar instâncias (dados isolados, porta ADB única, limites de RAM/CPU segundo o hardware).
- Persistência local (sem contas, sem telemetria, sem backend).
- Diagnóstico: SO, arquitetura, RAM, disco, virtualização, QEMU, ADB, registos e exportação de relatório.
- Gestor de APKs: seleção, SHA-256, aviso de origem desconhecida, instalação via ADB com resultado real e histórico.
- Consulta de atualizações no GitHub Releases.

## O que NÃO está pronto

Mapeamento de teclado, modo integrado, arrastar e largar APK, downloads automáticos de imagens/motor, partilha de pastas, captura de ecrã. Estão marcados como "Em desenvolvimento" e desativados na interface.

## Requisitos

- Node.js 20+ (para desenvolvimento).
- Para correr Android: QEMU (`qemu-system-x86_64`), ADB (platform-tools), virtualização ativa (KVM / WHPX / Hypervisor.framework) e uma imagem Android (qcow2/raw) obtida de fonte autorizada. O ANDROMAX **não inclui** imagens nem serviços Google.
- Hardware sugerido: 4 núcleos, 8 GB de RAM, 20 GB livres.
- Variáveis opcionais: `ANDROMAX_QEMU`, `ANDROMAX_ADB` (caminhos dos executáveis).

## Desenvolvimento

```bash
npm install
npm run lint
npm test
npm start
```

## Compilar pelo GitHub (a partir do telemóvel)

1. Crie um repositório no GitHub e envie o conteúdo da pasta `andromax` (extraia o zip primeiro; o GitHub não extrai zips).
2. Envie o ficheiro `build.yml` (fornecido à parte) para `.github/workflows/build.yml`. Em Upload files pode escrever esse caminho no nome do ficheiro.
3. Em **Actions**, o workflow "Build" corre em Windows, Linux e macOS e publica os instaladores como artefactos (separador do run → Artifacts).
4. Para uma release: crie uma tag `v0.1.0`; o workflow anexa os instaladores à release.

Nota: o resultado é um instalador **desktop** (`.exe`, `.AppImage`, `.dmg`), não um `.apk`. O build não prova que o emulador funciona: isso exige teste num computador real.

## Teste em computador real (Linux, primeira plataforma alvo)

1. `ls -l /dev/kvm` e utilizador no grupo `kvm`.
2. Instalar `qemu-system-x86` e `adb`.
3. Criar instância, indicar a imagem em Configurar, Iniciar.
4. Verificar `qemu.log` na pasta da instância e `adb devices` (porta mostrada no cartão).
5. Instalar um APK no Gestor de APKs.
Reporte os resultados para atualizar `STATUS.md`.

## Estrutura

`main.js` / `preload.js` (Electron) · `ui/` · `src/core` · `src/platform` · `src/adb` · `src/virtualization` · `scripts/` · `tests/`

## Licença

MIT. Dependências: Electron (MIT), electron-builder (MIT). QEMU (GPL) e ADB (Apache-2.0) são usados como programas externos e não são distribuídos.
