'use strict';
const api = window.andromax;
const view = document.getElementById('view');
const nav = document.getElementById('nav');

const STATUS_LABEL = { stopped: 'Desligada', starting: 'A iniciar', running: 'Em execução', stopping: 'A parar', error: 'Erro' };
const state = { page: 'dashboard', instances: [], diag: null, timer: null };

function h(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k === 'class') e.className = v;
    else if (v === true) e.setAttribute(k, '');
    else if (v !== false && v != null) e.setAttribute(k, v);
  }
  for (const kid of kids.flat()) {
    if (kid == null || kid === false) continue;
    e.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
  }
  return e;
}

function toast(msg, isErr) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast' + (isErr ? ' err' : '');
  t.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { t.hidden = true; }, 5000);
}

async function call(p, okMsg) {
  const r = await p;
  if (!r.ok) {
    toast(r.error, true);
    return null;
  }
  if (okMsg) toast(okMsg);
  return r.data;
}

const fmtBytes = (n) => (n == null ? 'desconhecido' : n >= 1e9 ? (n / 1e9).toFixed(1) + ' GB' : (n / 1e6).toFixed(1) + ' MB');

async function refreshInstances() {
  const d = await call(api.instances.list());
  if (d) state.instances = d;
}

async function refreshEngine() {
  const d = await call(api.diagnostics.get());
  if (!d) return;
  state.diag = d;
  const el = document.getElementById('engine-state');
  el.textContent = d.qemu.found
    ? `Motor: QEMU ${d.qemu.version || ''} detetado (experimental)`
    : 'Motor: QEMU não encontrado — veja Diagnóstico';
}

// ---------- Formulário de instância ----------
function instanceForm(initial, limits, onSubmit, submitLabel) {
  const f = {};
  const field = (key, label, el) => {
    f[key] = el;
    const id = 'f-' + key;
    el.id = id;
    return h('div', {}, h('label', { for: id }, label), el);
  };
  const num = (key, label, min, max, val) => field(key, label, h('input', { type: 'number', min, max, value: val }));
  const sel = (key, label, opts, val) => {
    const s = h('select', {}, opts.map(([v, t]) => h('option', { value: v, selected: v === val }, t)));
    return field(key, label, s);
  };
  const form = h('form', { class: 'stack' },
    h('div', { class: 'form' },
      field('name', 'Nome', h('input', { type: 'text', maxlength: 40, value: initial.name, required: true })),
      num('ramMb', `RAM (MB, máx. ${limits.maxRamMb})`, 512, limits.maxRamMb, initial.ramMb),
      num('cores', `Núcleos de CPU (máx. ${limits.maxCores})`, 1, limits.maxCores, initial.cores),
      num('storageGb', 'Armazenamento (GB)', 4, 256, initial.storageGb),
      num('width', 'Largura (px)', 320, 3840, initial.width),
      num('height', 'Altura (px)', 320, 3840, initial.height),
      num('dpi', 'Densidade (dpi)', 120, 640, initial.dpi),
      sel('orientation', 'Orientação', [['landscape', 'Horizontal'], ['portrait', 'Vertical']], initial.orientation),
      sel('displayMode', 'Modo de apresentação', [['window', 'Janela independente'], ['embedded', 'Integrado (em desenvolvimento)']], initial.displayMode),
      sel('accel', 'Aceleração', [['auto', 'Automática (KVM/WHPX/HVF)'], ['none', 'Sem aceleração (lento)']], initial.accel),
      field('imageFile', 'Ficheiro de imagem Android (opcional)', h('input', { type: 'text', value: initial.imageFile || '', placeholder: '/caminho/para/android.qcow2' }))
    ),
    h('p', { class: 'muted' }, 'Versões do Android: nenhuma imagem é incluída nem listada. Indique o ficheiro de imagem que obteve de uma fonte autorizada.'),
    h('div', { class: 'row' }, h('button', { class: 'btn primary', type: 'submit' }, submitLabel))
  );
  form.addEventListener('submit', (ev) => {
    ev.preventDefault();
    const n = (k) => Number(f[k].value);
    onSubmit({
      name: f.name.value, ramMb: n('ramMb'), cores: n('cores'), storageGb: n('storageGb'),
      width: n('width'), height: n('height'), dpi: n('dpi'), orientation: f.orientation.value,
      displayMode: f.displayMode.value, accel: f.accel.value, imageFile: f.imageFile.value.trim()
    });
  });
  return form;
}

function openConfigDialog(inst) {
  const dlg = document.getElementById('dlg');
  dlg.replaceChildren(
    h('h2', {}, 'Configurar: ' + inst.name),
    instanceForm(inst, state.diag.system.limits, async (cfg) => {
      const r = await call(api.instances.update(inst.id, cfg), 'Configuração guardada.');
      if (r) { dlg.close(); render(); }
    }, 'Guardar'),
    h('div', { class: 'row', style: 'margin-top:12px' }, h('button', { class: 'btn', type: 'button', onclick: () => dlg.close() }, 'Fechar'))
  );
  dlg.showModal();
}

// ---------- Cartão de instância ----------
function instanceCard(i) {
  const busy = i.status === 'starting' || i.status === 'stopping';
  const running = i.status === 'running';
  const act = async (fn, msg) => { await call(fn, msg); await refreshInstances(); render(); };
  return h('article', { class: 'card' },
    h('div', { class: 'row between' }, h('h2', {}, i.name), h('span', { class: 'badge ' + i.status }, STATUS_LABEL[i.status] || i.status)),
    h('p', { class: 'muted' }, `${i.ramMb} MB RAM · ${i.cores} núcleos · ${i.storageGb} GB · ${i.width}×${i.height} · ADB :${i.adbPort}`),
    i.lastError ? h('div', { class: 'notice err' }, i.lastError) : null,
    !i.imageFile ? h('p', { class: 'muted' }, 'Sem imagem Android configurada.') : null,
    h('div', { class: 'row', style: 'margin-top:10px' },
      h('button', { class: 'btn primary small', disabled: running || busy, onclick: () => act(api.instances.start(i.id)) }, 'Iniciar'),
      h('button', { class: 'btn small', disabled: !running, onclick: () => act(api.instances.stop(i.id)) }, 'Parar'),
      h('button', { class: 'btn small', disabled: !running, onclick: async () => { await call(api.instances.stop(i.id)); setTimeout(async () => { await call(api.instances.start(i.id)); await refreshInstances(); render(); }, 2500); } }, 'Reiniciar'),
      h('button', { class: 'btn small', disabled: running || busy, onclick: () => openConfigDialog(i) }, 'Configurar'),
      h('button', { class: 'btn small', disabled: running || busy, onclick: () => act(api.instances.clone(i.id), 'Instância clonada.') }, 'Clonar'),
      h('button', { class: 'btn small', onclick: () => act(api.instances.export(i.id)) }, 'Exportar'),
      h('button', { class: 'btn small danger', disabled: running || busy, onclick: () => { if (confirm(`Eliminar "${i.name}" e todos os seus dados? Esta ação não pode ser desfeita.`)) act(api.instances.remove(i.id), 'Instância eliminada.'); } }, 'Eliminar')
    )
  );
}

// ---------- Páginas ----------
const pages = {
  dashboard() {
    const total = state.instances.length;
    const running = state.instances.filter((i) => i.status === 'running').length;
    const d = state.diag;
    return h('div', { class: 'stack' },
      h('div', {}, h('h1', {}, 'Início'), h('p', { class: 'sub' }, 'Painel de gestão de instâncias Android.')),
      h('div', { class: 'grid' },
        h('div', { class: 'card' }, h('h2', {}, 'Instâncias'), h('p', {}, `${total} criada(s), ${running} em execução.`), h('button', { class: 'btn primary', onclick: () => go('create') }, 'Criar instância')),
        h('div', { class: 'card' }, h('h2', {}, 'Motor'), h('p', { class: 'muted' }, d ? (d.qemu.found ? `QEMU ${d.qemu.version || ''} detetado.` : d.qemu.hint) : '…')),
        h('div', { class: 'card' }, h('h2', {}, 'ADB'), h('p', { class: 'muted' }, d ? (d.adb.found ? `ADB ${d.adb.version || ''} detetado.` : d.adb.hint) : '…'))
      ),
      h('div', { class: 'notice' }, 'Estado do projeto: a interface e o gestor de instâncias estão funcionais. A execução real do Android depende de QEMU, aceleração e uma imagem Android compatível, e ainda não foi validada em hardware real. Consulte STATUS.md.')
    );
  },
  instances() {
    return h('div', { class: 'stack' },
      h('div', { class: 'row between' },
        h('div', {}, h('h1', {}, 'Minhas instâncias'), h('p', { class: 'sub' }, 'Inicie, pare e configure os seus dispositivos virtuais.')),
        h('div', { class: 'row' },
          h('button', { class: 'btn', onclick: async () => { const r = await call(api.instances.import(), 'Configuração importada.'); await refreshInstances(); if (r) render(); } }, 'Importar'),
          h('button', { class: 'btn primary', onclick: () => go('create') }, 'Criar instância'))),
      state.instances.length
        ? h('div', { class: 'grid' }, state.instances.map(instanceCard))
        : h('div', { class: 'card' }, 'Ainda não existem instâncias. Crie a primeira.')
    );
  },
  create() {
    const defaults = { name: 'Nova instância', ramMb: 2048, cores: 2, storageGb: 16, width: 1280, height: 720, dpi: 240, orientation: 'landscape', displayMode: 'window', accel: 'auto', imageFile: '' };
    const limits = state.diag ? state.diag.system.limits : { maxRamMb: 4096, maxCores: 2 };
    defaults.ramMb = Math.min(defaults.ramMb, limits.maxRamMb);
    defaults.cores = Math.min(defaults.cores, limits.maxCores);
    return h('div', { class: 'stack' },
      h('div', {}, h('h1', {}, 'Criar instância'), h('p', { class: 'sub' }, 'Device Studio: os limites seguem o hardware deste computador.')),
      h('div', { class: 'card' }, instanceForm(defaults, limits, async (cfg) => {
        const r = await call(api.instances.create(cfg), 'Instância criada.');
        if (r) { await refreshInstances(); go('instances'); }
      }, 'Criar instância'))
    );
  },
  apks() {
    const sel = { file: null };
    const out = h('div', {});
    const instSel = h('select', { id: 'apk-inst' }, state.instances.filter((i) => i.status === 'running').map((i) => h('option', { value: i.id }, i.name)));
    const info = h('div', { class: 'muted' }, 'Nenhum APK selecionado.');
    const installBtn = h('button', { class: 'btn primary', disabled: true, onclick: async () => {
      if (!instSel.value) return toast('Inicie uma instância primeiro.', true);
      if (!confirm('Instalar APK de origem desconhecida? Instale apenas ficheiros em que confia.')) return;
      const r = await call(api.apk.install(instSel.value, sel.file.path));
      if (r) out.replaceChildren(h('div', { class: 'notice ' + (r.ok ? 'ok' : 'err') }, (r.ok ? 'Instalado com sucesso. ' : 'Falha: ') + r.message));
      loadHistory();
    } }, 'Instalar na instância');
    const hist = h('div', {});
    async function loadHistory() {
      const rows = await call(api.apk.history());
      if (!rows) return;
      hist.replaceChildren(rows.length ? h('table', {}, h('tr', {}, ['Data', 'Instância', 'Ficheiro', 'Resultado'].map((t) => h('th', {}, t))),
        rows.map((r) => h('tr', {}, h('td', {}, new Date(r.t).toLocaleString()), h('td', {}, r.instance), h('td', {}, r.file), h('td', {}, r.ok ? 'Sucesso' : 'Falha')))) : h('p', { class: 'muted' }, 'Sem histórico.'));
    }
    loadHistory();
    return h('div', { class: 'stack' },
      h('div', {}, h('h1', {}, 'Gestor de APKs'), h('p', { class: 'sub' }, 'A instalação usa ADB e mostra o resultado real. Requer uma instância em execução.')),
      h('div', { class: 'card stack' },
        h('div', { class: 'row' }, h('button', { class: 'btn', onclick: async () => {
          const r = await call(api.apk.pick());
          if (!r) return;
          sel.file = r;
          info.textContent = `${r.name} · ${fmtBytes(r.size)} · SHA-256 ${r.sha256.slice(0, 16)}…`;
          installBtn.disabled = false;
        } }, 'Selecionar APK…'), h('button', { class: 'btn', disabled: true, title: 'Em desenvolvimento' }, 'Arrastar e largar (em desenvolvimento)')),
        info,
        h('div', {}, h('label', { for: 'apk-inst' }, 'Instância de destino (apenas em execução)'), instSel),
        installBtn, out),
      h('div', { class: 'card' }, h('h2', {}, 'Histórico de instalações'), hist)
    );
  },
  keymap() {
    return h('div', { class: 'stack' },
      h('div', {}, h('h1', {}, 'Mapeamento de teclado'), h('p', { class: 'sub' }, 'Em desenvolvimento.')),
      h('div', { class: 'card' }, h('p', {}, 'O mapeamento de teclas para toques exige um Android convidado funcional e injeção de entrada, ainda não implementados.'), h('button', { class: 'btn', disabled: true }, 'Criar perfil (em desenvolvimento)')));
  },
  downloads() {
    const out = h('div', {});
    return h('div', { class: 'stack' },
      h('div', {}, h('h1', {}, 'Downloads e atualizações'), h('p', { class: 'sub' }, 'Consulta o GitHub Releases do repositório definido em Definições.')),
      h('div', { class: 'card stack' },
        h('div', { class: 'row' }, h('button', { class: 'btn primary', onclick: async () => {
          const r = await call(api.updates.check());
          if (!r) return;
          out.replaceChildren(
            h('p', {}, `Versão instalada: ${r.current}`),
            r.latest ? h('p', {}, `Última versão publicada: ${r.latest}${r.newer ? ' (disponível)' : ' (está atualizado)'}`) : h('p', { class: 'muted' }, r.note),
            r.url ? h('button', { class: 'btn', onclick: () => call(api.openExternal(r.url)) }, 'Abrir página da release') : null,
            r.assets && r.assets.length ? h('ul', {}, r.assets.map((a) => h('li', {}, `${a.name} (${fmtBytes(a.size)})`))) : null);
        } }, 'Procurar atualizações')),
        out,
        h('p', { class: 'muted' }, 'Imagens Android e componentes do motor: gestão automática de downloads em desenvolvimento.'))
    );
  },
  settings() {
    const wrap = h('div', { class: 'card stack' }, 'A carregar…');
    call(api.settings.get()).then((s) => {
      if (!s) return;
      const theme = h('select', { id: 's-theme' }, [['dark', 'Escuro'], ['light', 'Claro']].map(([v, t]) => h('option', { value: v, selected: s.theme === v }, t)));
      const repo = h('input', { id: 's-repo', type: 'text', value: s.githubRepo || '', placeholder: 'utilizador/repositorio' });
      wrap.replaceChildren(
        h('div', {}, h('label', { for: 's-theme' }, 'Tema'), theme),
        h('div', {}, h('label', { for: 's-repo' }, 'Repositório GitHub para atualizações'), repo),
        h('p', { class: 'muted' }, 'O ANDROMAX não envia telemetria nem usa contas. Os dados ficam apenas neste computador.'),
        h('div', { class: 'row' }, h('button', { class: 'btn primary', onclick: async () => {
          const r = await call(api.settings.set({ theme: theme.value, githubRepo: repo.value.trim() }), 'Definições guardadas.');
          if (r) applyTheme(r.theme);
        } }, 'Guardar')));
    });
    return h('div', { class: 'stack' }, h('div', {}, h('h1', {}, 'Definições')), wrap);
  },
  diagnostics() {
    const wrap = h('div', { class: 'stack' }, 'A recolher…');
    refreshEngine().then(() => {
      const d = state.diag;
      if (!d) return;
      const s = d.system;
      const dt = (pairs) => h('dl', { class: 'kv' }, pairs.map(([k, v]) => [h('dt', {}, k), h('dd', {}, v)]));
      const virtTxt = s.virtualization.available === true ? `Disponível (${s.virtualization.accelerator})`
        : s.virtualization.available === false ? `Indisponível (${s.virtualization.accelerator})` : `Não verificável automaticamente (${s.virtualization.accelerator})`;
      wrap.replaceChildren(
        h('div', { class: 'row between' }, h('div', {}, h('h1', {}, 'Diagnóstico e registos')),
          h('button', { class: 'btn', onclick: async () => { const p = await call(api.diagnostics.export()); if (p) toast('Relatório guardado em ' + p); } }, 'Exportar relatório')),
        h('div', { class: 'card' }, h('h2', {}, 'Sistema'), dt([
          ['Sistema operativo', `${s.platform} ${s.osRelease}`], ['Arquitetura', s.arch], ['Processador', `${s.cpuModel} (${s.cpuCount} núcleos)`],
          ['RAM', `${fmtBytes(s.freeRamBytes)} livre de ${fmtBytes(s.totalRamBytes)}`], ['Disco livre (dados)', fmtBytes(s.diskFreeBytes)],
          ['Virtualização CPU', s.virtualization.cpuVirtualization === null ? 'Desconhecido' : s.virtualization.cpuVirtualization ? 'Sim' : 'Não'], ['Aceleração', virtTxt]]),
          s.virtualization.hints.length ? h('ul', {}, s.virtualization.hints.map((x) => h('li', {}, x))) : null),
        h('div', { class: 'card' }, h('h2', {}, 'Componentes'), dt([
          ['Motor (QEMU)', d.qemu.found ? `${d.qemu.version || 'versão desconhecida'} — ${d.qemu.path}` : d.qemu.hint],
          ['ADB', d.adb.found ? `${d.adb.version || 'versão desconhecida'} — ${d.adb.path}` : d.adb.hint],
          ['Imagens Android', `${d.images.configured} instância(s) com imagem, ${d.images.missing} em falta. ${d.images.note}`]])),
        h('div', { class: 'card' }, h('h2', {}, 'Últimos registos'),
          d.logs.length ? h('table', {}, d.logs.slice().reverse().map((l) => h('tr', {}, h('td', {}, new Date(l.t).toLocaleString()), h('td', {}, l.level), h('td', {}, l.msg)))) : h('p', { class: 'muted' }, 'Sem registos.')));
    });
    return wrap;
  },
  about() {
    const wrap = h('div', { class: 'card' }, 'A carregar…');
    call(api.about()).then((a) => {
      if (!a) return;
      wrap.replaceChildren(h('dl', { class: 'kv' }, [['Versão', a.version], ['Electron', a.electron], ['Node.js', a.node], ['Pasta de dados', a.dataDir], ['Licença', 'MIT']].map(([k, v]) => [h('dt', {}, k), h('dd', {}, v)])),
        h('p', { class: 'muted' }, 'ANDROMAX é um projeto independente, sem relação com outros emuladores. Não distribui imagens Android nem serviços Google.'));
    });
    return h('div', { class: 'stack' }, h('h1', {}, 'Sobre o ANDROMAX'), wrap);
  }
};

const NAV = [['dashboard', 'Início'], ['instances', 'Instâncias'], ['create', 'Criar'], ['apks', 'APKs'], ['keymap', 'Teclado'], ['downloads', 'Downloads'], ['diagnostics', 'Diagnóstico'], ['settings', 'Definições'], ['about', 'Sobre']];

function renderNav() {
  nav.replaceChildren(...NAV.map(([id, label]) => h('button', { type: 'button', 'aria-current': id === state.page ? 'page' : null, onclick: () => go(id) }, label)));
}

function render() {
  renderNav();
  view.replaceChildren(pages[state.page]());
}

async function go(page) {
  state.page = page;
  await refreshInstances();
  render();
  view.focus();
}

function applyTheme(t) {
  document.documentElement.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
}

document.getElementById('open-settings').addEventListener('click', () => go('settings'));

(async function init() {
  const s = await call(api.settings.get());
  if (s) applyTheme(s.theme);
  await refreshEngine();
  await go('dashboard');
  // Atualização periódica dos estados reais das instâncias.
  setInterval(async () => {
    if (state.page === 'instances' || state.page === 'dashboard') {
      if (document.getElementById('dlg').open) return;
      await refreshInstances();
      render();
    }
  }, 3000);
})();
