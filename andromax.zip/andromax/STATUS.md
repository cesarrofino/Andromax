# STATUS

## Concluído e testado (testes unitários)
- Persistência local atómica.
- Gestor de instâncias: criar, configurar, clonar, eliminar, exportar/importar, portas ADB únicas, recuperação após encerramento inesperado, validação de limites.
- Construção segura dos argumentos do QEMU (array, sem shell).
- Validação de APK.

## Implementado, não testado em ambiente real
- Interface Electron completa (não executada neste ambiente de geração: sem Electron instalado).
- Deteção de capacidades (Linux/Windows/macOS).
- Arranque/paragem do QEMU (experimental).
- Instalação de APK por ADB.
- Verificação de atualizações no GitHub Releases.
- Build por GitHub Actions nos três sistemas.

## Em desenvolvimento (desativado na UI)
- Mapeamento de teclado e perfis.
- Modo integrado no painel.
- Arrastar e largar APK.
- Downloads de imagens Android e componentes do motor.
- Partilha de pastas, transferência de ficheiros, captura de ecrã, áudio.

## Bloqueado (precisa de hardware/decisão externa)
- Validação do Android convidado: requer computador com virtualização e imagem Android legalmente obtida.
- Assinatura de instaladores: requer certificados.
