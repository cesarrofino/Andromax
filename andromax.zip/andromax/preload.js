'use strict';
const { contextBridge, ipcRenderer } = require('electron');

const call = (channel) => (...args) => ipcRenderer.invoke(channel, ...args);

contextBridge.exposeInMainWorld('andromax', {
  instances: {
    list: call('instances:list'),
    create: call('instances:create'),
    update: call('instances:update'),
    clone: call('instances:clone'),
    remove: call('instances:remove'),
    start: call('instances:start'),
    stop: call('instances:stop'),
    export: call('instances:export'),
    import: call('instances:import')
  },
  diagnostics: { get: call('diagnostics:get'), export: call('diagnostics:export') },
  settings: { get: call('settings:get'), set: call('settings:set') },
  apk: { pick: call('apk:pick'), info: call('apk:info'), install: call('apk:install'), history: call('apk:history') },
  updates: { check: call('updates:check') },
  openExternal: call('open:external'),
  about: call('app:about')
});
