'use strict';
// "Lint" básico: verifica a sintaxe de todos os ficheiros .js do projeto.
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const root = path.join(__dirname, '..');
const skip = new Set(['node_modules', 'dist', '.git']);
let failed = 0;

function walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (skip.has(e.name)) continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p);
    else if (e.name.endsWith('.js')) {
      try {
        execFileSync(process.execPath, ['--check', p], { stdio: 'pipe' });
      } catch (err) {
        failed++;
        console.error(`ERRO de sintaxe em ${path.relative(root, p)}:\n${err.stderr}`);
      }
    }
  }
}

walk(root);
if (failed) process.exit(1);
console.log('Sintaxe OK.');
