# LIMITAÇÕES CONHECIDAS

## Gerais
- Sem imagens Android incluídas; o utilizador indica o ficheiro. Nenhuma versão do Android é declarada como suportada.
- O estado "Em execução" significa que o processo QEMU está ativo, não que o Android terminou de arrancar.
- Sem Google Play Store/Play Services.
- Sem aceleração gráfica validada (OpenGL/Vulkan) nem garantias de FPS ou compatibilidade com jogos.
- Instaladores não assinados (avisos de segurança do SO).

## Linux
- Requer `/dev/kvm` acessível (grupo `kvm`). Sem KVM, só emulação TCG (muito lenta).
- Plataforma prioritária para validação; ainda não validada.

## Windows
- Usa WHPX (Plataforma do Hipervisor do Windows). O estado do WHPX não é detetado automaticamente.
- QEMU e ADB têm de ser instalados à parte.

## macOS
- Hypervisor.framework; em Apple Silicon imagens x86 correm só por emulação lenta. Imagens arm64 não foram avaliadas.
- Instalador .dmg sem assinatura/notarização.
