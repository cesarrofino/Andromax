'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { Store } = require('../src/core/store');
const { InstanceManager, ValidationError } = require('../src/core/instances');
const { buildArgs } = require('../src/virtualization/engine');
const { validateApk } = require('../src/adb/adb');

function mk() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'andromax-'));
  const store = new Store(path.join(dir, 'db.json'), { instances: [] });
  return { dir, store, mgr: new InstanceManager(store, dir, () => ({ maxRamMb: 8192, maxCores: 4 })) };
}

test('cria instância com id, diretório e porta próprios', () => {
  const { mgr } = mk();
  const a = mgr.create({ name: 'A' });
  const b = mgr.create({ name: 'B' });
  assert.notStrictEqual(a.id, b.id);
  assert.notStrictEqual(a.adbPort, b.adbPort);
  assert.ok(fs.existsSync(a.dir));
  assert.strictEqual(a.status, 'stopped');
});

test('rejeita recursos acima dos limites do hardware', () => {
  const { mgr } = mk();
  assert.throws(() => mgr.create({ name: 'X', ramMb: 999999 }), ValidationError);
  assert.throws(() => mgr.create({ name: 'X', cores: 64 }), ValidationError);
  assert.throws(() => mgr.create({ name: '' }), ValidationError);
});

test('clona instância com novo id e porta', () => {
  const { mgr } = mk();
  const a = mgr.create({ name: 'Orig' });
  fs.writeFileSync(path.join(a.dir, 'disco.img'), 'x');
  const c = mgr.clone(a.id);
  assert.notStrictEqual(c.id, a.id);
  assert.notStrictEqual(c.adbPort, a.adbPort);
  assert.ok(fs.existsSync(path.join(c.dir, 'disco.img')));
});

test('elimina apenas o diretório da instância', () => {
  const { mgr, dir } = mk();
  const a = mgr.create({ name: 'Del' });
  mgr.remove(a.id);
  assert.ok(!fs.existsSync(a.dir));
  assert.ok(fs.existsSync(dir));
  assert.strictEqual(mgr.list().length, 0);
});

test('não permite configurar nem eliminar instância em execução', () => {
  const { mgr } = mk();
  const a = mgr.create({ name: 'Run' });
  mgr.setStatus(a.id, 'running');
  assert.throws(() => mgr.update(a.id, { name: 'Z' }), ValidationError);
  assert.throws(() => mgr.remove(a.id), ValidationError);
});

test('recupera de encerramento inesperado ao reiniciar', () => {
  const { mgr, store, dir } = mk();
  const a = mgr.create({ name: 'Crash' });
  mgr.setStatus(a.id, 'running');
  const mgr2 = new InstanceManager(new Store(store.file, { instances: [] }), dir);
  assert.strictEqual(mgr2.get(a.id).status, 'stopped');
});

test('exporta e importa configuração', () => {
  const { mgr } = mk();
  const a = mgr.create({ name: 'Exp', ramMb: 1024 });
  const copy = mgr.importConfig(mgr.exportConfig(a.id));
  assert.strictEqual(copy.ramMb, 1024);
  assert.throws(() => mgr.importConfig({ foo: 1 }), ValidationError);
});

test('argumentos do QEMU são um array sem shell', () => {
  const args = buildArgs({ id: 'ab12', ramMb: 2048, cores: 2, imageFile: '/x/a b.qcow2', adbPort: 5555 }, 'tcg');
  assert.ok(Array.isArray(args));
  assert.ok(args.includes('file=/x/a b.qcow2,if=virtio,format=qcow2'));
});

test('validateApk rejeita ficheiros inválidos', () => {
  assert.throws(() => validateApk('/tmp/nao-existe.txt'));
  assert.throws(() => validateApk(''));
});
