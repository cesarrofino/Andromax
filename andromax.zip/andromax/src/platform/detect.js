'use strict';
// Deteção de capacidades do sistema, com adaptadores por sistema operativo.
const os = require('os');
const fs = require('fs');
const { execFileSync } = require('child_process');

function run(cmd, args, timeout = 8000) {
  try {
    return execFileSync(cmd, args, { encoding: 'utf8', timeout, stdio: ['ignore', 'pipe', 'ignore'] }).trim();
  } catch {
    return null;
  }
}

const adapters = {
  linux() {
    let cpuFlag = null;
    try {
      const info = fs.readFileSync('/proc/cpuinfo', 'utf8');
      cpuFlag = /\b(vmx|svm)\b/.test(info);
    } catch {}
    const kvm = fs.existsSync('/dev/kvm');
    let kvmAccess = false;
    if (kvm) {
      try {
        fs.accessSync('/dev/kvm', fs.constants.R_OK | fs.constants.W_OK);
        kvmAccess = true;
      } catch {}
    }
    const ok = cpuFlag !== false && kvm && kvmAccess;
    const hints = [];
    if (cpuFlag === false) hints.push('O processador não expõe virtualização (vmx/svm). Ative VT-x/AMD-V na BIOS/UEFI.');
    if (!kvm) hints.push('/dev/kvm não existe. Carregue o módulo kvm (kvm_intel/kvm_amd) ou ative a virtualização na BIOS.');
    if (kvm && !kvmAccess) hints.push('Sem permissão em /dev/kvm. Adicione o utilizador ao grupo "kvm" e reinicie a sessão.');
    return { accelerator: 'kvm', cpuVirtualization: cpuFlag, available: ok, hints };
  },
  win32() {
    const virt = run('powershell', ['-NoProfile', '-Command', '(Get-CimInstance Win32_Processor).VirtualizationFirmwareEnabled']);
    const cpuFlag = virt === null ? null : /true/i.test(virt);
    const hints = [];
    if (cpuFlag === false) hints.push('Virtualização desativada na BIOS/UEFI. Ative VT-x/AMD-V.');
    hints.push('O QEMU usa WHPX: ative "Plataforma do Hipervisor do Windows" em Funcionalidades do Windows e reinicie.');
    // WHPX não é verificado automaticamente: não afirmamos que está ativo.
    return { accelerator: 'whpx', cpuVirtualization: cpuFlag, available: null, hints };
  },
  darwin() {
    const hv = run('sysctl', ['-n', 'kern.hv_support']);
    const cpuFlag = hv === null ? null : hv.trim() === '1';
    const hints = [];
    if (cpuFlag === false) hints.push('Hypervisor.framework não está disponível neste Mac.');
    if (os.arch() === 'arm64') hints.push('Em Apple Silicon o convidado Android precisa de imagem arm64; imagens x86 só correrão por emulação lenta (TCG).');
    return { accelerator: 'hvf', cpuVirtualization: cpuFlag, available: cpuFlag, hints };
  }
};

function diskFree(dir) {
  try {
    fs.mkdirSync(dir, { recursive: true });
    const s = fs.statfsSync(dir);
    return Number(s.bavail) * Number(s.bsize);
  } catch {
    return null;
  }
}

function detect(dataDir) {
  const platform = process.platform;
  const adapter = adapters[platform];
  const virt = adapter ? adapter() : { accelerator: null, cpuVirtualization: null, available: false, hints: ['Sistema operativo não suportado.'] };
  const totalRam = os.totalmem();
  return {
    platform,
    osRelease: os.release(),
    osVersion: typeof os.version === 'function' ? os.version() : '',
    arch: os.arch(),
    cpuModel: (os.cpus()[0] || {}).model || 'desconhecido',
    cpuCount: os.cpus().length,
    totalRamBytes: totalRam,
    freeRamBytes: os.freemem(),
    diskFreeBytes: diskFree(dataDir),
    virtualization: virt,
    limits: {
      // Nunca permitir mais de 75% da RAM física nem mais núcleos do que existem.
      maxRamMb: Math.max(512, Math.floor((totalRam * 0.75) / 1048576)),
      maxCores: Math.max(1, os.cpus().length)
    }
  };
}

module.exports = { detect };
