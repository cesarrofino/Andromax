'use strict';
// Integração ADB. Usa execFile com argumentos em array (sem shell).
const fs = require('fs');
const path = require('path');
const { execFile, execFileSync } = require('child_process');

function which(bin) {
  const cmd = process.platform === 'win32' ? 'where' : 'which';
  try {
    const out = execFileSync(cmd, [bin], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] });
    return out.split(/\r?\n/)[0].trim() || null;
  } catch {
    return null;
  }
}

function findAdb() {
  const env = process.env.ANDROMAX_ADB;
  if (env && fs.existsSync(env)) return env;
  return which('adb');
}

function run(adbPath, args, timeout = 30000) {
  return new Promise((resolve) => {
    execFile(adbPath, args, { timeout, encoding: 'utf8' }, (err, stdout, stderr) => {
      resolve({ ok: !err, code: err ? err.code : 0, stdout: stdout || '', stderr: stderr || (err ? err.message : '') });
    });
  });
}

async function status() {
  const p = findAdb();
  if (!p) {
    return {
      found: false,
      path: null,
      version: null,
      hint: 'ADB não encontrado. Instale o "Android platform-tools" e adicione-o ao PATH, ou defina ANDROMAX_ADB com o caminho do executável.'
    };
  }
  const r = await run(p, ['version'], 8000);
  const m = r.stdout.match(/Android Debug Bridge version ([\d.]+)/);
  return { found: true, path: p, version: m ? m[1] : null, hint: null };
}

function validateApk(file) {
  if (typeof file !== 'string' || !file || file.includes('\0')) throw new Error('Caminho do APK inválido.');
  if (path.extname(file).toLowerCase() !== '.apk') throw new Error('O ficheiro não tem extensão .apk.');
  const st = fs.statSync(file);
  if (!st.isFile()) throw new Error('O caminho não é um ficheiro.');
  return st;
}

async function install(port, apkFile) {
  validateApk(apkFile);
  if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('Porta ADB inválida.');
  const p = findAdb();
  if (!p) throw new Error('ADB não encontrado.');
  const serial = `127.0.0.1:${port}`;
  const c = await run(p, ['connect', serial], 15000);
  if (!c.ok || /failed|cannot|unable/i.test(c.stdout)) {
    return { ok: false, message: `Não foi possível ligar ao Android (${serial}): ${(c.stdout || c.stderr).trim()}` };
  }
  const r = await run(p, ['-s', serial, 'install', '-r', apkFile], 180000);
  const out = (r.stdout + r.stderr).trim();
  return { ok: r.ok && /Success/.test(out), message: out };
}

module.exports = { status, install, findAdb, validateApk, which };
