'use strict';
// Motor de virtualização (QEMU). EXPERIMENTAL: o arranque só é tentado quando existem
// QEMU instalado e uma imagem de disco indicada pelo utilizador. Nada é simulado.
const fs = require('fs');
const path = require('path');
const { spawn, execFileSync } = require('child_process');
const { which } = require('../adb/adb');

const procs = new Map();

function findQemu() {
  const env = process.env.ANDROMAX_QEMU;
  if (env && fs.existsSync(env)) return env;
  return which('qemu-system-x86_64');
}

function qemuStatus() {
  const p = findQemu();
  if (!p) {
    return {
      found: false,
      path: null,
      version: null,
      hint: 'QEMU não encontrado. Instale o qemu-system-x86_64 ou defina ANDROMAX_QEMU com o caminho do executável.'
    };
  }
  let version = null;
  try {
    const out = execFileSync(p, ['--version'], { encoding: 'utf8', timeout: 8000, stdio: ['ignore', 'pipe', 'ignore'] });
    const m = out.match(/version ([\d.]+)/);
    version = m ? m[1] : null;
  } catch {}
  return { found: true, path: p, version, hint: null };
}

function accelFor(inst) {
  if (inst.accel === 'none') return 'tcg';
  return { linux: 'kvm', win32: 'whpx', darwin: 'hvf' }[process.platform] || 'tcg';
}

function buildArgs(inst, accel) {
  const fmt = path.extname(inst.imageFile).toLowerCase() === '.qcow2' ? 'qcow2' : 'raw';
  return [
    '-accel', accel,
    '-m', String(inst.ramMb),
    '-smp', String(inst.cores),
    '-drive', `file=${inst.imageFile},if=virtio,format=${fmt}`,
    '-netdev', `user,id=n0,hostfwd=tcp:127.0.0.1:${inst.adbPort}-:5555`,
    '-device', 'virtio-net-pci,netdev=n0',
    '-device', 'qemu-xhci',
    '-device', 'usb-tablet',
    '-name', `andromax-${inst.id}`
  ];
}

/**
 * @returns {{ok:boolean,error?:string}}
 */
function start(inst, onExit) {
  if (procs.has(inst.id)) return { ok: false, error: 'A instância já está em execução.' };
  const q = findQemu();
  if (!q) return { ok: false, error: 'Motor QEMU não encontrado. Veja Diagnóstico para instruções.' };
  if (!inst.imageFile) return { ok: false, error: 'Esta instância não tem imagem Android configurada. Indique um ficheiro de imagem em Configurar.' };
  if (!fs.existsSync(inst.imageFile) || !fs.statSync(inst.imageFile).isFile()) {
    return { ok: false, error: `Imagem não encontrada: ${inst.imageFile}` };
  }
  const args = buildArgs(inst, accelFor(inst));
  let logFd;
  try {
    logFd = fs.openSync(path.join(inst.dir, 'qemu.log'), 'a');
    const child = spawn(q, args, { stdio: ['ignore', logFd, logFd], detached: false });
    procs.set(inst.id, { child, stopping: false });
    child.on('error', (err) => {
      procs.delete(inst.id);
      onExit(inst.id, `Falha ao iniciar o QEMU: ${err.message}`);
    });
    child.on('exit', (code, signal) => {
      const entry = procs.get(inst.id);
      procs.delete(inst.id);
      try { fs.closeSync(logFd); } catch {}
      if (entry && entry.stopping) onExit(inst.id, null);
      else onExit(inst.id, code === 0 ? null : `O QEMU terminou (código ${code ?? signal}). Consulte qemu.log da instância.`);
    });
    return { ok: true };
  } catch (err) {
    if (logFd !== undefined) try { fs.closeSync(logFd); } catch {}
    return { ok: false, error: err.message };
  }
}

function stop(id) {
  const entry = procs.get(id);
  if (!entry) return false;
  entry.stopping = true;
  entry.child.kill('SIGTERM');
  setTimeout(() => {
    if (procs.has(id)) entry.child.kill('SIGKILL');
  }, 8000).unref();
  return true;
}

function stopAll() {
  for (const id of [...procs.keys()]) stop(id);
}

function isRunning(id) {
  return procs.has(id);
}

module.exports = { qemuStatus, start, stop, stopAll, isRunning, buildArgs, findQemu };
