'use strict';
// Gestor de instâncias: validação, persistência, clonagem, portas ADB únicas.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class ValidationError extends Error {
  constructor(errors) {
    super(errors.join(' '));
    this.name = 'ValidationError';
    this.errors = errors;
  }
}

const DEFAULTS = {
  name: 'Nova instância',
  androidVersion: null,
  imageFile: '',
  ramMb: 2048,
  cores: 2,
  storageGb: 16,
  width: 1280,
  height: 720,
  dpi: 240,
  orientation: 'landscape',
  displayMode: 'window',
  accel: 'auto'
};

const TRANSIENT = ['starting', 'running', 'stopping'];

function isInt(v, min, max) {
  return Number.isInteger(v) && v >= min && v <= max;
}

function validate(cfg, limits = { maxRamMb: 16384, maxCores: 8 }) {
  const e = [];
  const name = String(cfg.name ?? '').trim();
  if (!name || name.length > 40) e.push('O nome deve ter entre 1 e 40 caracteres.');
  if (/[\x00-\x1f]/.test(name)) e.push('O nome contém caracteres inválidos.');
  if (!isInt(cfg.ramMb, 512, limits.maxRamMb)) e.push(`A RAM deve estar entre 512 MB e ${limits.maxRamMb} MB (limite do seu computador).`);
  if (!isInt(cfg.cores, 1, limits.maxCores)) e.push(`Os núcleos devem estar entre 1 e ${limits.maxCores}.`);
  if (!isInt(cfg.storageGb, 4, 256)) e.push('O armazenamento deve estar entre 4 e 256 GB.');
  if (!isInt(cfg.width, 320, 3840) || !isInt(cfg.height, 320, 3840)) e.push('A resolução deve estar entre 320 e 3840 pixéis.');
  if (!isInt(cfg.dpi, 120, 640)) e.push('A densidade deve estar entre 120 e 640 dpi.');
  if (!['portrait', 'landscape'].includes(cfg.orientation)) e.push('Orientação inválida.');
  if (!['window', 'embedded'].includes(cfg.displayMode)) e.push('Modo de apresentação inválido.');
  if (!['auto', 'none'].includes(cfg.accel)) e.push('Opção de aceleração inválida.');
  if (cfg.imageFile && typeof cfg.imageFile !== 'string') e.push('Caminho da imagem inválido.');
  if (typeof cfg.imageFile === 'string' && cfg.imageFile.includes('\0')) e.push('Caminho da imagem inválido.');
  if (e.length) throw new ValidationError(e);
  return { ...cfg, name };
}

class InstanceManager {
  /**
   * @param {Store} store
   * @param {string} baseDir diretório de dados (contém instances/)
   * @param {() => {maxRamMb:number,maxCores:number}} getLimits
   */
  constructor(store, baseDir, getLimits) {
    this.store = store;
    this.baseDir = baseDir;
    this.instancesDir = path.join(baseDir, 'instances');
    this.getLimits = getLimits || (() => ({ maxRamMb: 16384, maxCores: 8 }));
    fs.mkdirSync(this.instancesDir, { recursive: true });
    // Encerramentos inesperados: nenhum processo sobrevive a um reinício da aplicação.
    const list = this.store.get('instances') || [];
    let changed = false;
    for (const i of list) {
      if (TRANSIENT.includes(i.status)) {
        i.status = 'stopped';
        changed = true;
      }
    }
    if (changed) this.store.set('instances', list);
  }

  _all() {
    return this.store.get('instances') || [];
  }

  _save(list) {
    this.store.set('instances', list);
  }

  _newId() {
    const used = new Set(this._all().map((i) => i.id));
    let id;
    do {
      id = crypto.randomBytes(4).toString('hex');
    } while (used.has(id));
    return id;
  }

  _allocPort() {
    const used = new Set(this._all().map((i) => i.adbPort));
    for (let p = 5555; p <= 5755; p += 2) if (!used.has(p)) return p;
    throw new ValidationError(['Não há portas ADB livres (máximo de instâncias atingido).']);
  }

  _dirFor(id) {
    const dir = path.resolve(this.instancesDir, id);
    if (path.dirname(dir) !== path.resolve(this.instancesDir)) throw new Error('Caminho de instância inválido.');
    return dir;
  }

  list() {
    return this._all().map((i) => ({ ...i }));
  }

  get(id) {
    const i = this._all().find((x) => x.id === id);
    if (!i) throw new Error('Instância não encontrada.');
    return i;
  }

  create(input = {}) {
    const cfg = validate({ ...DEFAULTS, ...input }, this.getLimits());
    const id = this._newId();
    const inst = {
      ...cfg,
      id,
      adbPort: this._allocPort(),
      dir: this._dirFor(id),
      status: 'stopped',
      lastError: null,
      createdAt: new Date().toISOString()
    };
    fs.mkdirSync(inst.dir, { recursive: true });
    this._save([...this._all(), inst]);
    return { ...inst };
  }

  update(id, patch) {
    const list = this._all();
    const idx = list.findIndex((x) => x.id === id);
    if (idx < 0) throw new Error('Instância não encontrada.');
    if (list[idx].status !== 'stopped' && list[idx].status !== 'error') {
      throw new ValidationError(['Pare a instância antes de a configurar.']);
    }
    const allowed = Object.keys(DEFAULTS);
    const clean = {};
    for (const k of allowed) if (k in patch) clean[k] = patch[k];
    const merged = validate({ ...list[idx], ...clean }, this.getLimits());
    list[idx] = { ...list[idx], ...merged };
    this._save(list);
    return { ...list[idx] };
  }

  rename(id, name) {
    return this.update(id, { name });
  }

  clone(id) {
    const src = this.get(id);
    if (src.status !== 'stopped' && src.status !== 'error') {
      throw new ValidationError(['Pare a instância antes de a clonar.']);
    }
    const newId = this._newId();
    const copy = {
      ...src,
      id: newId,
      name: `${src.name} (cópia)`.slice(0, 40),
      adbPort: this._allocPort(),
      dir: this._dirFor(newId),
      status: 'stopped',
      lastError: null,
      createdAt: new Date().toISOString()
    };
    if (fs.existsSync(src.dir)) fs.cpSync(src.dir, copy.dir, { recursive: true });
    else fs.mkdirSync(copy.dir, { recursive: true });
    this._save([...this._all(), copy]);
    return { ...copy };
  }

  remove(id) {
    const inst = this.get(id);
    if (inst.status !== 'stopped' && inst.status !== 'error') {
      throw new ValidationError(['Pare a instância antes de a eliminar.']);
    }
    const dir = this._dirFor(id); // garante que só apagamos dentro de instances/
    fs.rmSync(dir, { recursive: true, force: true });
    this._save(this._all().filter((x) => x.id !== id));
  }

  setStatus(id, status, lastError = null) {
    const list = this._all();
    const idx = list.findIndex((x) => x.id === id);
    if (idx < 0) return;
    list[idx].status = status;
    list[idx].lastError = lastError;
    this._save(list);
  }

  exportConfig(id) {
    const { name, androidVersion, ramMb, cores, storageGb, width, height, dpi, orientation, displayMode, accel } = this.get(id);
    return { andromax: 1, config: { name, androidVersion, ramMb, cores, storageGb, width, height, dpi, orientation, displayMode, accel } };
  }

  importConfig(obj) {
    if (!obj || obj.andromax !== 1 || typeof obj.config !== 'object') {
      throw new ValidationError(['Ficheiro de configuração inválido.']);
    }
    return this.create(obj.config);
  }
}

module.exports = { InstanceManager, ValidationError, validate, DEFAULTS };
