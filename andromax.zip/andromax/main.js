'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const { Store } = require('./src/core/store');
const { InstanceManager } = require('./src/core/instances');
const { detect } = require('./src/platform/detect');
const adb = require('./src/adb/adb');
const engine = require('./src/virtualization/engine');

let win = null;
let store;
let manager;
let caps;

const SETTINGS_DEFAULTS = { theme: 'dark', locale: 'pt', githubRepo: '' };

function log(level, msg) {
  const logs = store.get('logs') || [];
  logs.push({ t: new Date().toISOString(), level, msg: String(msg) });
  store.set('logs', logs.slice(-200));
}

function settings() {
  return { ...SETTINGS_DEFAULTS, ...(store.get('settings') || {}) };
}

function createWindow() {
  win = new BrowserWindow({
    width: 1240,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: '#0b1220',
    title: 'ANDROMAX',
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, 'ui', 'index.html'));
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
}

function wrap(fn) {
  return async (_e, ...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (err) {
      log('error', err.message);
      return { ok: false, error: err.message };
    }
  };
}

function handle(name, fn) {
  ipcMain.handle(name, wrap(fn));
}

function registerIpc() {
  handle('instances:list', () => manager.list());
  handle('instances:create', (cfg) => manager.create(cfg));
  handle('instances:update', (id, patch) => manager.update(id, patch));
  handle('instances:clone', (id) => manager.clone(id));
  handle('instances:remove', (id) => manager.remove(id));
  handle('instances:export', async (id) => {
    const r = await dialog.showSaveDialog(win, { defaultPath: 'instancia.andromax.json', filters: [{ name: 'JSON', extensions: ['json'] }] });
    if (r.canceled) return null;
    fs.writeFileSync(r.filePath, JSON.stringify(manager.exportConfig(id), null, 2));
    return r.filePath;
  });
  handle('instances:import', async () => {
    const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'JSON', extensions: ['json'] }] });
    if (r.canceled) return null;
    const obj = JSON.parse(fs.readFileSync(r.filePaths[0], 'utf8'));
    return manager.importConfig(obj);
  });

  handle('instances:start', (id) => {
    const inst = manager.get(id);
    if (inst.status !== 'stopped' && inst.status !== 'error') throw new Error('A instância já está em arranque ou execução.');
    manager.setStatus(id, 'starting');
    const res = engine.start(inst, (iid, err) => {
      manager.setStatus(iid, err ? 'error' : 'stopped', err);
      if (err) log('error', `[${iid}] ${err}`);
    });
    if (!res.ok) {
      manager.setStatus(id, 'error', res.error);
      log('error', `[${id}] ${res.error}`);
      throw new Error(res.error);
    }
    // Estado honesto: o processo QEMU está ativo; isso não garante que o Android já arrancou.
    manager.setStatus(id, 'running');
    log('info', `[${id}] processo QEMU iniciado`);
    return true;
  });
  handle('instances:stop', (id) => {
    const inst = manager.get(id);
    if (!engine.isRunning(id)) {
      manager.setStatus(id, 'stopped');
      return true;
    }
    manager.setStatus(inst.id, 'stopping');
    engine.stop(id);
    return true;
  });

  handle('diagnostics:get', async () => {
    const d = detect(manager.baseDir);
    caps = d;
    const insts = manager.list();
    return {
      system: d,
      qemu: engine.qemuStatus(),
      adb: await adb.status(),
      images: {
        configured: insts.filter((i) => i.imageFile).length,
        missing: insts.filter((i) => i.imageFile && !fs.existsSync(i.imageFile)).length,
        note: 'O ANDROMAX não inclui imagens Android. Indique o ficheiro de imagem em cada instância.'
      },
      logs: (store.get('logs') || []).slice(-50),
      appVersion: app.getVersion()
    };
  });
  handle('diagnostics:export', async () => {
    const r = await dialog.showSaveDialog(win, { defaultPath: 'andromax-diagnostico.json', filters: [{ name: 'JSON', extensions: ['json'] }] });
    if (r.canceled) return null;
    const report = {
      generatedAt: new Date().toISOString(),
      appVersion: app.getVersion(),
      system: detect(manager.baseDir),
      qemu: engine.qemuStatus(),
      adb: await adb.status(),
      logs: store.get('logs') || []
    };
    fs.writeFileSync(r.filePath, JSON.stringify(report, null, 2));
    return r.filePath;
  });

  handle('settings:get', () => settings());
  handle('settings:set', (patch) => {
    const cur = settings();
    if (patch.theme && ['dark', 'light'].includes(patch.theme)) cur.theme = patch.theme;
    if (typeof patch.githubRepo === 'string') {
      if (patch.githubRepo && !/^[\w.-]+\/[\w.-]+$/.test(patch.githubRepo)) throw new Error('Repositório inválido. Use o formato utilizador/repositório.');
      cur.githubRepo = patch.githubRepo;
    }
    store.set('settings', cur);
    return cur;
  });

  handle('apk:pick', async () => {
    const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'APK', extensions: ['apk'] }] });
    if (r.canceled) return null;
    return apkInfo(r.filePaths[0]);
  });
  handle('apk:info', (file) => apkInfo(file));
  handle('apk:install', async (id, file) => {
    const inst = manager.get(id);
    if (inst.status !== 'running') throw new Error('A instância tem de estar em execução.');
    const res = await adb.install(inst.adbPort, file);
    const hist = store.get('apkHistory') || [];
    hist.push({ t: new Date().toISOString(), instance: inst.name, file: path.basename(file), ok: res.ok, message: res.message });
    store.set('apkHistory', hist.slice(-100));
    if (!res.ok) log('error', `Instalação de APK falhou: ${res.message}`);
    return res;
  });
  handle('apk:history', () => (store.get('apkHistory') || []).slice().reverse());

  handle('updates:check', async () => {
    const repo = settings().githubRepo;
    if (!repo) throw new Error('Defina o repositório GitHub em Definições para consultar atualizações.');
    const res = await fetch(`https://api.github.com/repos/${repo}/releases/latest`, { headers: { Accept: 'application/vnd.github+json', 'User-Agent': 'andromax' } });
    if (res.status === 404) return { current: app.getVersion(), latest: null, note: 'Ainda não há releases publicadas neste repositório.' };
    if (!res.ok) throw new Error(`GitHub respondeu ${res.status}.`);
    const j = await res.json();
    const latest = String(j.tag_name || '').replace(/^v/, '');
    return {
      current: app.getVersion(),
      latest,
      url: j.html_url,
      assets: (j.assets || []).map((a) => ({ name: a.name, size: a.size })),
      newer: latest && latest !== app.getVersion()
    };
  });
  handle('open:external', (url) => {
    if (typeof url !== 'string' || !/^https:\/\/github\.com\//.test(url)) throw new Error('Ligação não permitida.');
    return shell.openExternal(url);
  });
  handle('app:about', () => ({ version: app.getVersion(), electron: process.versions.electron, node: process.versions.node, dataDir: manager.baseDir }));
}

function apkInfo(file) {
  const st = adb.validateApk(file);
  const hash = crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
  return { path: file, name: path.basename(file), size: st.size, sha256: hash };
}

app.whenReady().then(() => {
  const dataDir = path.join(app.getPath('userData'), 'data');
  store = new Store(path.join(dataDir, 'andromax.json'), { instances: [], logs: [], apkHistory: [] });
  caps = detect(dataDir);
  manager = new InstanceManager(store, dataDir, () => caps.limits);
  registerIpc();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('before-quit', () => engine.stopAll());
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
